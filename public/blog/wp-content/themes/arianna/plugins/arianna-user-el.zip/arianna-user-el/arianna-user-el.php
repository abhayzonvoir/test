<?php
    /*
    Plugin Name: Arianna User El
    Plugin URI: http://demo.alonsa.info/arianna
    Description: Display the User El for the author box
    Author: Arianna
    Version: 1.0
    Author URI: http://demo.alonsa.info/arianna/author/arianna
    */
    if ( ! function_exists( 'arianna_contact_data' ) ) {  
        function arianna_contact_data($contactmethods) {
        
            unset($contactmethods['aim']);
            unset($contactmethods['yim']);
            unset($contactmethods['jabber']);
            $contactmethods['publicemail'] = 'Public Email';
            $contactmethods['twitter'] = 'Twitter Username';
            $contactmethods['facebook'] = 'Facebook URL';
            $contactmethods['youtube'] = 'Youtube Username';
            $contactmethods['googleplus'] = 'Google+ (Entire URL)';
             
            return $contactmethods;
        }
    }
    add_filter('user_contactmethods', 'arianna_contact_data');
?>